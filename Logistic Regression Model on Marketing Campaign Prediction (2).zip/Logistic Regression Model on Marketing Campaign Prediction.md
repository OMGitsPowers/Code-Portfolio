For this project I'll be using data obatined from Kaggle that will be used to predict the outcome of a response. 
The dataset for this project can be found at the following site. 

Marketing Campaign Positive Response Prediction
https://www.kaggle.com/datasets/sujithmandala/marketing-campaign-positive-response-prediction



Importing the necessary packages that could be needed for this project. 


```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
```


```python
hf = pd.read_csv('campaign_responses.csv')
hf
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>age</th>
      <th>gender</th>
      <th>annual_income</th>
      <th>credit_score</th>
      <th>employed</th>
      <th>marital_status</th>
      <th>no_of_children</th>
      <th>responded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>35</td>
      <td>Male</td>
      <td>65000</td>
      <td>720</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>28</td>
      <td>Female</td>
      <td>45000</td>
      <td>680</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>42</td>
      <td>Male</td>
      <td>85000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>31</td>
      <td>Female</td>
      <td>55000</td>
      <td>710</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>No</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>47</td>
      <td>Male</td>
      <td>95000</td>
      <td>790</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>25</td>
      <td>Female</td>
      <td>38000</td>
      <td>630</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>39</td>
      <td>Male</td>
      <td>72000</td>
      <td>740</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>33</td>
      <td>Female</td>
      <td>48000</td>
      <td>670</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>51</td>
      <td>Male</td>
      <td>110000</td>
      <td>820</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>27</td>
      <td>Female</td>
      <td>40000</td>
      <td>620</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>44</td>
      <td>Male</td>
      <td>90000</td>
      <td>780</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>30</td>
      <td>Female</td>
      <td>52000</td>
      <td>690</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>36</td>
      <td>Male</td>
      <td>75000</td>
      <td>730</td>
      <td>Yes</td>
      <td>Married</td>
      <td>1</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>29</td>
      <td>Female</td>
      <td>45000</td>
      <td>660</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>49</td>
      <td>Male</td>
      <td>105000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>26</td>
      <td>Female</td>
      <td>36000</td>
      <td>610</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>41</td>
      <td>Male</td>
      <td>85000</td>
      <td>760</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>32</td>
      <td>Female</td>
      <td>54000</td>
      <td>700</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>37</td>
      <td>Male</td>
      <td>80000</td>
      <td>740</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>34</td>
      <td>Female</td>
      <td>60000</td>
      <td>720</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>No</td>
    </tr>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>43</td>
      <td>Male</td>
      <td>92000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>28</td>
      <td>Female</td>
      <td>42000</td>
      <td>640</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>38</td>
      <td>Male</td>
      <td>78000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>31</td>
      <td>Female</td>
      <td>48000</td>
      <td>680</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>45</td>
      <td>Male</td>
      <td>98000</td>
      <td>790</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>27</td>
      <td>Female</td>
      <td>40000</td>
      <td>630</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>40</td>
      <td>Male</td>
      <td>85000</td>
      <td>760</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>35</td>
      <td>Female</td>
      <td>62000</td>
      <td>710</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>No</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>46</td>
      <td>Male</td>
      <td>100000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>29</td>
      <td>Female</td>
      <td>44000</td>
      <td>650</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>42</td>
      <td>Male</td>
      <td>90000</td>
      <td>780</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>33</td>
      <td>Female</td>
      <td>56000</td>
      <td>690</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>39</td>
      <td>Male</td>
      <td>82000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>30</td>
      <td>Female</td>
      <td>50000</td>
      <td>670</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>48</td>
      <td>Male</td>
      <td>105000</td>
      <td>810</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>25</td>
      <td>Female</td>
      <td>35000</td>
      <td>600</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>41</td>
      <td>Male</td>
      <td>88000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>34</td>
      <td>Female</td>
      <td>58000</td>
      <td>700</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>No</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>43</td>
      <td>Male</td>
      <td>95000</td>
      <td>780</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>28</td>
      <td>Female</td>
      <td>43000</td>
      <td>640</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>40</th>
      <td>41</td>
      <td>37</td>
      <td>Male</td>
      <td>80000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>41</th>
      <td>42</td>
      <td>32</td>
      <td>Female</td>
      <td>52000</td>
      <td>680</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>42</th>
      <td>43</td>
      <td>45</td>
      <td>Male</td>
      <td>100000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>43</th>
      <td>44</td>
      <td>30</td>
      <td>Female</td>
      <td>46000</td>
      <td>660</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>44</th>
      <td>45</td>
      <td>40</td>
      <td>Male</td>
      <td>88000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>45</th>
      <td>46</td>
      <td>36</td>
      <td>Female</td>
      <td>64000</td>
      <td>720</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>No</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47</td>
      <td>47</td>
      <td>Male</td>
      <td>102000</td>
      <td>790</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>47</th>
      <td>48</td>
      <td>26</td>
      <td>Female</td>
      <td>38000</td>
      <td>620</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>48</th>
      <td>49</td>
      <td>42</td>
      <td>Male</td>
      <td>90000</td>
      <td>760</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>49</th>
      <td>50</td>
      <td>33</td>
      <td>Female</td>
      <td>54000</td>
      <td>690</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>50</th>
      <td>51</td>
      <td>39</td>
      <td>Male</td>
      <td>85000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>51</th>
      <td>52</td>
      <td>31</td>
      <td>Female</td>
      <td>50000</td>
      <td>680</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>52</th>
      <td>53</td>
      <td>46</td>
      <td>Male</td>
      <td>98000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>53</th>
      <td>54</td>
      <td>28</td>
      <td>Female</td>
      <td>42000</td>
      <td>630</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>No</td>
    </tr>
    <tr>
      <th>54</th>
      <td>55</td>
      <td>41</td>
      <td>Male</td>
      <td>90000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>55</th>
      <td>56</td>
      <td>34</td>
      <td>Female</td>
      <td>60000</td>
      <td>710</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>No</td>
    </tr>
  </tbody>
</table>
</div>




```python
hf.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 56 entries, 0 to 55
    Data columns (total 9 columns):
     #   Column          Non-Null Count  Dtype 
    ---  ------          --------------  ----- 
     0   customer_id     56 non-null     int64 
     1   age             56 non-null     int64 
     2   gender          56 non-null     object
     3   annual_income   56 non-null     int64 
     4   credit_score    56 non-null     int64 
     5   employed        56 non-null     object
     6   marital_status  56 non-null     object
     7   no_of_children  56 non-null     int64 
     8   responded       56 non-null     object
    dtypes: int64(5), object(4)
    memory usage: 4.1+ KB
    


```python
hf.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>age</th>
      <th>annual_income</th>
      <th>credit_score</th>
      <th>no_of_children</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>56.000000</td>
      <td>56.000000</td>
      <td>56.000000</td>
      <td>56.000000</td>
      <td>56.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>28.500000</td>
      <td>36.214286</td>
      <td>69017.857143</td>
      <td>719.107143</td>
      <td>1.285714</td>
    </tr>
    <tr>
      <th>std</th>
      <td>16.309506</td>
      <td>7.088311</td>
      <td>22784.756524</td>
      <td>60.340753</td>
      <td>1.186504</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>25.000000</td>
      <td>35000.000000</td>
      <td>600.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>14.750000</td>
      <td>30.000000</td>
      <td>48000.000000</td>
      <td>677.500000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>28.500000</td>
      <td>35.500000</td>
      <td>64500.000000</td>
      <td>720.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>42.250000</td>
      <td>42.000000</td>
      <td>90000.000000</td>
      <td>770.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>56.000000</td>
      <td>51.000000</td>
      <td>110000.000000</td>
      <td>820.000000</td>
      <td>3.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
hf.isna().sum()
```




    customer_id       0
    age               0
    gender            0
    annual_income     0
    credit_score      0
    employed          0
    marital_status    0
    no_of_children    0
    responded         0
    dtype: int64




```python
hf['responded'] = hf['responded'].replace(['Yes', 'No'], [1, 0])
```


```python
hf
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>age</th>
      <th>gender</th>
      <th>annual_income</th>
      <th>credit_score</th>
      <th>employed</th>
      <th>marital_status</th>
      <th>no_of_children</th>
      <th>responded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>35</td>
      <td>Male</td>
      <td>65000</td>
      <td>720</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>28</td>
      <td>Female</td>
      <td>45000</td>
      <td>680</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>42</td>
      <td>Male</td>
      <td>85000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>31</td>
      <td>Female</td>
      <td>55000</td>
      <td>710</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>47</td>
      <td>Male</td>
      <td>95000</td>
      <td>790</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>25</td>
      <td>Female</td>
      <td>38000</td>
      <td>630</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>39</td>
      <td>Male</td>
      <td>72000</td>
      <td>740</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>33</td>
      <td>Female</td>
      <td>48000</td>
      <td>670</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>51</td>
      <td>Male</td>
      <td>110000</td>
      <td>820</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>27</td>
      <td>Female</td>
      <td>40000</td>
      <td>620</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>44</td>
      <td>Male</td>
      <td>90000</td>
      <td>780</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>30</td>
      <td>Female</td>
      <td>52000</td>
      <td>690</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>36</td>
      <td>Male</td>
      <td>75000</td>
      <td>730</td>
      <td>Yes</td>
      <td>Married</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>29</td>
      <td>Female</td>
      <td>45000</td>
      <td>660</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>49</td>
      <td>Male</td>
      <td>105000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>26</td>
      <td>Female</td>
      <td>36000</td>
      <td>610</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>41</td>
      <td>Male</td>
      <td>85000</td>
      <td>760</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>32</td>
      <td>Female</td>
      <td>54000</td>
      <td>700</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>37</td>
      <td>Male</td>
      <td>80000</td>
      <td>740</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>34</td>
      <td>Female</td>
      <td>60000</td>
      <td>720</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>43</td>
      <td>Male</td>
      <td>92000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>28</td>
      <td>Female</td>
      <td>42000</td>
      <td>640</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>38</td>
      <td>Male</td>
      <td>78000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>31</td>
      <td>Female</td>
      <td>48000</td>
      <td>680</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>45</td>
      <td>Male</td>
      <td>98000</td>
      <td>790</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>27</td>
      <td>Female</td>
      <td>40000</td>
      <td>630</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>40</td>
      <td>Male</td>
      <td>85000</td>
      <td>760</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>35</td>
      <td>Female</td>
      <td>62000</td>
      <td>710</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>46</td>
      <td>Male</td>
      <td>100000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>29</td>
      <td>Female</td>
      <td>44000</td>
      <td>650</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>42</td>
      <td>Male</td>
      <td>90000</td>
      <td>780</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>33</td>
      <td>Female</td>
      <td>56000</td>
      <td>690</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>39</td>
      <td>Male</td>
      <td>82000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>30</td>
      <td>Female</td>
      <td>50000</td>
      <td>670</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>48</td>
      <td>Male</td>
      <td>105000</td>
      <td>810</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>25</td>
      <td>Female</td>
      <td>35000</td>
      <td>600</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>41</td>
      <td>Male</td>
      <td>88000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>34</td>
      <td>Female</td>
      <td>58000</td>
      <td>700</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>43</td>
      <td>Male</td>
      <td>95000</td>
      <td>780</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>28</td>
      <td>Female</td>
      <td>43000</td>
      <td>640</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>40</th>
      <td>41</td>
      <td>37</td>
      <td>Male</td>
      <td>80000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>41</th>
      <td>42</td>
      <td>32</td>
      <td>Female</td>
      <td>52000</td>
      <td>680</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>42</th>
      <td>43</td>
      <td>45</td>
      <td>Male</td>
      <td>100000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>43</th>
      <td>44</td>
      <td>30</td>
      <td>Female</td>
      <td>46000</td>
      <td>660</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>45</td>
      <td>40</td>
      <td>Male</td>
      <td>88000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>45</th>
      <td>46</td>
      <td>36</td>
      <td>Female</td>
      <td>64000</td>
      <td>720</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47</td>
      <td>47</td>
      <td>Male</td>
      <td>102000</td>
      <td>790</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>47</th>
      <td>48</td>
      <td>26</td>
      <td>Female</td>
      <td>38000</td>
      <td>620</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>48</th>
      <td>49</td>
      <td>42</td>
      <td>Male</td>
      <td>90000</td>
      <td>760</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>49</th>
      <td>50</td>
      <td>33</td>
      <td>Female</td>
      <td>54000</td>
      <td>690</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>51</td>
      <td>39</td>
      <td>Male</td>
      <td>85000</td>
      <td>750</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>51</th>
      <td>52</td>
      <td>31</td>
      <td>Female</td>
      <td>50000</td>
      <td>680</td>
      <td>Yes</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>52</th>
      <td>53</td>
      <td>46</td>
      <td>Male</td>
      <td>98000</td>
      <td>800</td>
      <td>Yes</td>
      <td>Married</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>53</th>
      <td>54</td>
      <td>28</td>
      <td>Female</td>
      <td>42000</td>
      <td>630</td>
      <td>No</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>54</th>
      <td>55</td>
      <td>41</td>
      <td>Male</td>
      <td>90000</td>
      <td>770</td>
      <td>Yes</td>
      <td>Married</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>55</th>
      <td>56</td>
      <td>34</td>
      <td>Female</td>
      <td>60000</td>
      <td>710</td>
      <td>Yes</td>
      <td>Single</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.histplot(hf, x = 'age')
plt.xlabel('Patient Ages')
plt.ylabel('Total Count')
plt.title('Total Age Count')
```




    Text(0.5, 1.0, 'Total Age Count')




    
![png](output_9_1.png)
    



```python
sns.histplot(hf, x = 'annual_income')
plt.xlabel('Annual Income')
plt.ylabel('Total Count')
plt.title('Annual Income Count')
```




    Text(0.5, 1.0, 'Annual Income Count')




    
![png](output_10_1.png)
    



```python
sns.histplot(hf, x = 'credit_score')
plt.xlabel('Credit Score')
plt.ylabel('Total Count')
plt.title('Credit Score Count')
```




    Text(0.5, 1.0, 'Credit Score Count')




    
![png](output_11_1.png)
    



```python
corr = hf.corr()
```


```python
plt.figure(figsize = (10, 5))
sns.heatmap(corr, cmap = 'coolwarm', annot = True)
plt.show()
```


    
![png](output_13_0.png)
    



```python
hf_x = hf.drop(columns = 'responded')
hf_x.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 56 entries, 0 to 55
    Data columns (total 8 columns):
     #   Column          Non-Null Count  Dtype 
    ---  ------          --------------  ----- 
     0   customer_id     56 non-null     int64 
     1   age             56 non-null     int64 
     2   gender          56 non-null     object
     3   annual_income   56 non-null     int64 
     4   credit_score    56 non-null     int64 
     5   employed        56 non-null     object
     6   marital_status  56 non-null     object
     7   no_of_children  56 non-null     int64 
    dtypes: int64(5), object(3)
    memory usage: 3.6+ KB
    


```python
hf_x.shape
```




    (56, 8)




```python
hf_x = pd.get_dummies(hf_x)
```


```python
hf_x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>age</th>
      <th>annual_income</th>
      <th>credit_score</th>
      <th>no_of_children</th>
      <th>gender_Female</th>
      <th>gender_Male</th>
      <th>employed_No</th>
      <th>employed_Yes</th>
      <th>marital_status_Married</th>
      <th>marital_status_Single</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>35</td>
      <td>65000</td>
      <td>720</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>28</td>
      <td>45000</td>
      <td>680</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>42</td>
      <td>85000</td>
      <td>750</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>31</td>
      <td>55000</td>
      <td>710</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>47</td>
      <td>95000</td>
      <td>790</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
hf_y = hf.iloc[:, -1].values
hf_y
```




    array([1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
           1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
           1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], dtype=int64)




```python
hf_y.shape
```




    (56,)




```python
hf_y1 = pd.DataFrame()
```


```python
hf_y1 = hf_y
```


```python
print(type(hf_y1))
```

    <class 'numpy.ndarray'>
    


```python
hf_y
```




    array([1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
           1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
           1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], dtype=int64)




```python
x_train, x_test, y_train, y_test = train_test_split(hf_x, hf_y, test_size = .30, random_state = 58)
```


```python
log = LogisticRegression()
log
```




    LogisticRegression()




```python
log.fit(x_train, y_train)
```




    LogisticRegression()




```python
x_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>age</th>
      <th>annual_income</th>
      <th>credit_score</th>
      <th>no_of_children</th>
      <th>gender_Female</th>
      <th>gender_Male</th>
      <th>employed_No</th>
      <th>employed_Yes</th>
      <th>marital_status_Married</th>
      <th>marital_status_Single</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>28</td>
      <td>45000</td>
      <td>680</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>53</th>
      <td>54</td>
      <td>28</td>
      <td>42000</td>
      <td>630</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>34</td>
      <td>60000</td>
      <td>720</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>26</td>
      <td>36000</td>
      <td>610</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>29</td>
      <td>45000</td>
      <td>660</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
y_test
```




    array([1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1], dtype=int64)




```python
y_pred = log.predict(x_test)
```


```python
print(log.coef_)
```

    [[-8.80741643e-02 -5.80794508e-03  2.03687158e-03 -1.75417657e-01
       1.82442508e-03 -2.03917462e-03  1.72561516e-03 -2.87476505e-04
      -2.60829547e-05  1.72561516e-03 -2.03917462e-03]]
    


```python
print(log.intercept_)
```

    [-0.00047042]
    


```python
accuracy_score(y_test, y_pred, normalize = True)
```




    1.0




```python

```
